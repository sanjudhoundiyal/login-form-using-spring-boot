package com.Smart.Contact.Manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSmartContactManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
