package com.Smart.Contact.Manager.Cofiguration;

import com.Smart.Contact.Manager.Entity.User;
import com.Smart.Contact.Manager.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UserDetailServiceimp implements UserDetailsService {

   @Autowired
   private UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
       User user = userRepo.getUserByUserName(username);

       if (user==null)
       {
           throw new UsernameNotFoundException("could not find");
       }
CustomerUserDetails customerUserDetails= new CustomerUserDetails(user);
        return customerUserDetails;
    }
}
