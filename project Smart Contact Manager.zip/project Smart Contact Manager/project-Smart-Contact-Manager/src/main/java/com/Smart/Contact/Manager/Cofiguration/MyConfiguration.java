package com.Smart.Contact.Manager.Cofiguration;

import com.Smart.Contact.Manager.Cofiguration.UserDetailServiceimp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.core.userdetails.UserDetailsService;

@Configuration
public class MyConfiguration {

    // 1️⃣ UserDetailsService bean
    @Bean
    public UserDetailsService userDetailsService() {
        return new UserDetailServiceimp(); // Aapki custom implementation
    }

    // 2️⃣ Password encoder
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // 3️⃣ DaoAuthenticationProvider bean
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService());
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    // 4️⃣ AuthenticationManager bean
    @Bean
    public AuthenticationManager authManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
                .authenticationProvider(authenticationProvider())
                .build();
    }

    // 5️⃣ SecurityFilterChain for HTTP security
    @Bean

    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        .requestMatchers("/user/**").hasRole("USER")
                        .requestMatchers("/**").permitAll()
                )
                .formLogin(form -> form
                        .loginPage("/signin")              // ✅ custom login page
                        .loginProcessingUrl("/dologin")    // ✅ must match form action
                        .defaultSuccessUrl("/index", true) // ✅ redirect after success
                        .failureUrl("/login-error")        // ✅ redirect on failure
                )
                .csrf(csrf -> csrf.disable());          // ✅ disable CSRF if not using token

        return http.build();
    }


}