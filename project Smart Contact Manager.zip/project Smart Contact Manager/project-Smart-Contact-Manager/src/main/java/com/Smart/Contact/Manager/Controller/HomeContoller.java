package com.Smart.Contact.Manager.Controller;

import com.Smart.Contact.Manager.Entity.User;
import com.Smart.Contact.Manager.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeContoller {
@Autowired
    private UserRepo userRepo;

 @GetMapping("/test")
    public String test()
 {
     User user=new User();
     user.setName("Sanjay");
     user.setEmail("sanju@gmai.com");
       userRepo.save(user);
     return  "working";
 }

}
