package com.Smart.Contact.Manager.Controller;

import com.Smart.Contact.Manager.Entity.User;
import com.Smart.Contact.Manager.Message.Message;
import com.Smart.Contact.Manager.Repository.UserRepo;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller

public class HomeController {


    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    @Autowired
    private UserRepo userRepo;// database

    @RequestMapping("/")
    public String get() {
        return "home";
    }

    @RequestMapping("about")
    public String about(Model model) {
        model.addAttribute("name", "sanjay");
        return "about";
    }


@GetMapping("/signin")
public  String login(Model model)
{
    model.addAttribute("this"," this is book");
    return  "login";
}

    @RequestMapping("signup")
    public String signup(Model model) {
        model.addAttribute("title", "Resister- Smart Contact Manager");
        model.addAttribute("user", new User());

        return "signup";
    }




    // Handle request from signup form
    @RequestMapping(value = "/do_register", method = RequestMethod.POST)
    public String handleSignup(
            @Valid @ModelAttribute("user") User user,
            BindingResult result,
            @RequestParam(value = "agreement", defaultValue = "false") boolean agreement,
            Model model,
            HttpSession session,
            RedirectAttributes redirectAttributes) { // RedirectAttributes जोड़ा

        try {
            // 1️⃣ Check for validation errors
            if (result.hasErrors()) {
                model.addAttribute("user", user);
                return "signup";
            }

            // 2️⃣ Terms & conditions check
            if (!agreement) {
                model.addAttribute("user", user);
                // Safe message set using redirect
                redirectAttributes.addFlashAttribute("message",
                        new Message("You must accept the terms and conditions!", "alert-danger"));
                return "redirect:/signup"; // redirect prevents duplicate submit
            }

            // 3️⃣ Set default values
            user.setRole("ROLE_USER");
            user.setEnabled(true);
            user.setImageUrl("default.png");
user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
            // 4️⃣ Save user
            userRepo.save(user);

            // 5️⃣ Success message
            session.setAttribute("message", new Message("Successfully registered!", "success"));
            return "redirect:/signup";

        } catch (org.springframework.dao.DataIntegrityViolationException ex) {
            ex.printStackTrace(); // log for developers
            model.addAttribute("user", user);
            session.setAttribute("message", new Message("Email already in use. Please try another.", "danger"));
            return "redirect:/signup";
        } catch (Exception e) {
            e.printStackTrace(); // log for developers
            model.addAttribute("user", user);
            session.setAttribute("message", new Message("Something went wrong. Please try again later.", "danger"));
            return "redirect:/signup";
        }

    }
}