package com.Smart.Contact.Manager.Controller;

import com.Smart.Contact.Manager.Entity.User;
import com.Smart.Contact.Manager.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.security.Principal;

@Controller

public class securityController {

    @Autowired
    private UserRepo userRepo;
@RequestMapping("/index")
public String setting(Principal principal, Model  model)
{
String  username=principal.getName();

    System.out.println(username);
     User user=userRepo.getUserByUserName(username);
     model.addAttribute("user"+user);
    System.out.println(user);
    return"LOGIN1";
}

}
