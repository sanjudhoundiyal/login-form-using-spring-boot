package com.Smart.Contact.Manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSmartContactManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSmartContactManagerApplication.class, args);
	}

}
